package com.example.QuickOrdenrespaldo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuickOrdenrespaldoApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuickOrdenrespaldoApplication.class, args);
	}

}
