package com.example.QuickOrdenrespaldo.controller;

import com.example.QuickOrdenrespaldo.model.Pedido;
import com.example.QuickOrdenrespaldo.model.Estado;
import com.example.QuickOrdenrespaldo.service.PedidoService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import java.util.List;

@RestController
@RequestMapping("/pedidos")
public class PedidoController {
    private final PedidoService service;

    public PedidoController(PedidoService service) { this.service = service; }

    @GetMapping
    public List<Pedido> listar() { return service.obtenerTodos(); }

    @GetMapping("/{id}")
    public Pedido buscar(@PathVariable Long id) { return service.obtenerPorId(id); }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED) // 201 Created [cite: 116]
    public Pedido crear(@RequestBody Pedido pedido) { return service.crear(pedido); }

    @PutMapping("/{id}")
    public Pedido editar(@PathVariable Long id, @RequestBody Pedido pedido) {
        return service.actualizar(id, pedido);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT) // 204 No Content [cite: 117]
    public void borrar(@PathVariable Long id) { service.eliminar(id); }

    @GetMapping("/estado/{estado}")
    public List<Pedido> filtrar(@PathVariable Estado estado) {
        return service.filtrarPorEstado(estado);
    }
}