package com.example.QuickOrdenrespaldo.repository;

public class repository {}