package com.example.QuickOrdenrespaldo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class QuickOrdenrespaldoApplicationTests {

	@Test
	void contextLoads() {
	}

}
